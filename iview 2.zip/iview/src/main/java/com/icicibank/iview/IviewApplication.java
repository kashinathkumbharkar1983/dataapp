package com.icicibank.iview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(IviewApplication.class, args);
	}
}
