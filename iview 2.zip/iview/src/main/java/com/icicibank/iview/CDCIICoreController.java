package com.icicibank.iview;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CDCIICoreController {

	@RequestMapping("/CDCICore")
    public String getMinistatement(@RequestParam(value="AccountNo", defaultValue="0000") String AccountNo)  {
		//Your codes need to go here returing icore response string
        return "Greetings from Spring Boot!";
    }
}
